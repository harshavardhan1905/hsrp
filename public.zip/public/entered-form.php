<html>
    <head>
        <link rel="stylesheet" href="../public/style/style.css">
    </head>
    <body>
            <header>
                <div class="head-sec">
                    <h1>HSRP Online Booking</h1>
        
                    <nav>
                <a href="#home" onclick="window.location.href='../public/index.php'">Home</a>
                <a href="#contact-us" onclick="window.location.href='../public/contact.php'">Contact Us</a>
                <a href="#privacy-policy">Privacy Policy</a>
                <a href="#refund-policy" onclick="window.location.href='../public/refund_policy.php'">Refund Policy</a>
                <a href="#terms-conditions" onclick="window.location.href='../public/terms.php'">Terms & Conditions</a>
                
            </nav>
                </div>
                <marquee behavior="scroll" direction="left" class="float-content">Booking Open for all states <span>Book Your High-Security Number Plates (HSRP) - HSRP Booking Now Open</span>  - It's now easier than ever to re-gister your Wheeler and Book the mandatory High-Security Number Plates</marquee>
        
            </header>
        <div class="container" id="payment-details">
            
            <div id="entered_details" class="">
                <!-- <h2>Entered Details:</h2>
                <p><strong>State:</strong><span id="result_state"></span></p>
                <p><strong>Wheeler Reg No:</strong><span id="result_wh_rg_no"></span></p>
                <p><strong>Chassic No:</strong><span id="result_chassis_no"></span></p>
                <p><strong>Engine No:</strong><span id="result_eng_no"></span></p>
    
    
                <p><strong>Name:</strong><span id="result_name"></span></p>
                <p><strong>Email:</strong><span id="result_email"></span></p>
                <p><strong>Phone No:</strong><span id="result_phone"></span></p>
                <p><strong>Address:</strong><span id="result_address"></span></p> -->
    
                <label for="accept-terms">
                    <input type="checkbox" id="accept-terms" required >
                    I agree to HSRP <a href="../terms.html" target="_blank">Terms & Conditions</a>
                </label>
                
                <div class="paym-btns">
                    <button id="to-payment" onclick="window.location.href='../public/payment-form.php'">confirm and pay</button>
                    <button type="button" id="pay-later-to-home" onclick="window.location.href='../public/index.php'">Pay Later</button>
                    <div id="success-alert" class="alert alert-success" style="display: none;">
                        Pay Later is successful! Returning to the home page.
                    </div>
                </div>
    
    
                
    
             </div>
        </div>
        <footer>
            <p>&copy; 2024 HSRP. All rights reserved.</p>
        </footer>
    
        <script src="../public/script/script.js"></script>
        
    </body>
</html>
