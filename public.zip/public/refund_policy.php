<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Refund policy</title>
    <link rel="stylesheet" href="/style/style.css">

</head>
<body>
   <main class="term-class">
    <h1 style="border-bottom: 2px solid pink; padding-bottom: 20px;">Refund Policy</h1>
    <p>
    <strong>Eligibility: </strong>You can request a refund within 30 days of purchase. To qualify, the item must be unused, in its original packaging, and in the same condition as received. Certain goods are exempt from returns.
    
    </p>
    <p>
    <strong>Non-Returnable Items:</strong> Items not in their original condition, damaged, missing parts (not due to our error), or returned after 30 days cannot be refunded.
    
    </p>
    <p>
    <strong>Partial Refunds: </strong>Applicable to opened Number Plates or items not in their original condition.
    
    </p>
    <p>
    <strong>Process:</strong> Once we receive and inspect your return, we'll notify you via email. Please note, it may take some time for the refund to be processed by your credit card company or bank. If you don't receive your refund after a reasonable period, contact us at support@bookhsrpnic.com.
    
    </p>
    <p>
    <strong>Sale Items:</strong> Only regular-priced items are eligible for refunds; sale items are non-refundable.
    
    </p>
    <p>
    <strong>Shipping Costs:</strong> Return shipping costs are your responsibility and are non-refundable. If a refund is issued, return shipping costs will be deducted. For items over $75, consider using a trackable shipping service or purchasing shipping insurance.
    
    </p>
    <h1 style="border-bottom: 2px solid pink; padding-bottom: 20px;">Cancellation Policy</h1>
    
    <p>
    <strong>Notification: </strong>We will inform you of the approval or rejection of your refund request. If approved, your refund will be processed to your credit card or original method of payment within a specified timeframe.
    
    </p>
    <p>
    <strong>Late or Missing Refunds:</strong> If you haven’t received your refund, check your bank account again. If necessary, contact us for further assistance.
    
    </p>
    <p>
    <strong>Exchanges:</strong> We only replace items if they are defective or damaged. To exchange for the same item, email us at support@bookhsrpnic.com.
    
    </p>
   </main>
</body>
</html>