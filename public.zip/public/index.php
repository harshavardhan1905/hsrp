<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HSRP Online Booking</title>
    <link rel="stylesheet" href="../public/style/style.css">

    <style>
        main {
            padding: 20px;
            max-width: 100%;
            margin: 20px ;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .grid-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }
        @media screen and (max-width:768px) {
            .grid-container{
                grid-template-columns: repeat(1, 1fr);
            }
        }
        .grid-item {
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
            max-width: 322px;
        }
        .grid-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }
        .grid-item h2 {
            font-size: 1.5rem;
            color: #4CAF50;
            margin-bottom: 10px;
        }
        .grid-item p {
            font-size: 1rem;
            line-height: 1.6;
            margin-bottom: 20px;
            color: #666;
        }
        .grid-item a {
            background-color: #4CAF50;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 25px;
            font-size: 1rem;
            display: inline-block;
            transition: background-color 0.3s;
        }
        .grid-item a:hover {
            background-color: #45a049;
        }
        .counts {
            display: flex;
            flex-direction: row;
            /* gap: 15px; */
            font-family: Arial, sans-serif;
        }

        .count-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #ffffff;
            padding: 10px 15px;
            border-radius: 5px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            font-size: 1rem;
            font-weight: bold;
        }

        .count-item label {
            color: #555;
            font-weight: 600;
        }

        .count-item span {
            color: #007BFF;
            font-weight: 700;
            font-size: 1.2rem;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .grid-item {
                flex-direction: column;
                align-items: stretch;
            }

            .count-item {
                font-size: 0.9rem;
                padding: 8px 12px;
            }
        }
    </style>
</head>
<body>
    
        <div class="index-con">
            <header id="home">
                <div class="head-sec">
                    <h1>HSRP Online Booking</h1>
        
                    <nav>
                        <a href="#home" onclick="window.location.href='../public/index.php'">Home</a>
                        <a href="#contact-us" onclick="window.location.href='../public/contact.php'">Contact Us</a>
                        <a href="#privacy-policy">Privacy Policy</a>
                        <a href="#refund-policy" onclick="window.location.href='../public/refund_policy.php'">Refund Policy</a>
                        <a href="#terms-conditions" onclick="window.location.href='../public/terms.php'">Terms & Conditions</a>
                    </nav>
                </div>
                <marquee behavior="scroll" direction="left" class="float-content">Booking Open for all states <span>Book Your High-Security Number Plates (HSRP) - HSRP Booking Now Open</span>  - It's now easier than ever to re-gister your Wheeler and Book the mandatory High-Security Number Plates</marquee>
        
            </header>
            <div class="banner">
                <img src="../public/assets/Flagbanner.jpg" alt="Banner Image">
            </div>
            <main>
                <div class="grid-container">
                    <div class="grid-item">
                        <p></p>
                        <h2>High Security Registration Plate</h2>
                        <p>Details about High Security Registration Plate with Colour Sticker.</p>
                        <a href="../public/booking-form.php" target="_top">Book</a>
                    </div>
                    <div class="grid-item">
                        <h2>Two Wheeler Plate</h2>
                        <p>Details about Two Wheeler Plate.</p>
                        <a href="../public/booking-form.php">Book</a>
                    </div>
                    <div class="grid-item">
                        <h2>Only Colour Sticker</h2>
                        <p>Details about Only Colour Sticker.</p>
                        <a href="../public/booking-form.php">Book</a>
                    </div>
                    <div class="grid-item">
                        <h2>Four Wheeler Plate</h2>
                        <p>Details about Four Wheeler Plate.</p>
                        <a href="../public/booking-form.php">Book</a>
                    </div>
                    <div class="grid-item">
                        <h2>Heavy Wheeler Plate</h2>
                        <p>Details about Heavy Wheeler Plate.</p>
                        <a href="../public/booking-form.php">Book</a>
                    </div>
                    <div class="grid-item">
                        <h2>Tractor & Trailer Number Plate</h2>
                        <p>Details about Tractor & Trailer Number Plate.</p>
                        <a href="../public/booking-form.php">Book</a>
                    </div>
                    <div class="grid-item">
                        <h2>Electric Vehicle Number Plate</h2>
                        <p>Details about Electric Vehicle Number Plate.</p>
                        <a href="../public/booking-form.php">Book</a>
                    </div>
        
                    <div class="grid-item">
                        <aside href="#home" class="counts">
                            <label for="booking_count">Bookings:</label>
                            <span id="booking_count">1</span>
                            <label for="user_count">Users:</label>
                            <span id="user_count">1</span>
                            <label for="payment_count">Payments:</label>
                            <span id="payment_count">1</span>
                        </aside>
                    </div>
                </div>
            </main>
        </div>
    <footer>
        <p>&copy; 2024 HSRP. All rights reserved.</p>
    </footer>
    <script src="/script/script.js"></script>
</body>
</html>
