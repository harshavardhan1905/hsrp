<?php
// Database connection
$servername = "localhost";
$username = "dev_harsha";
$password = "Harsha@123";
$dbname = "hsrpbooking";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form data is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['wh_r_no'], $_POST['name'], $_POST['email'], $_POST['phone'], $_POST['address'])) {
        // Get form data
        $wh_r_no = $_POST['wh_r_no'];
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $address = $_POST['address'];

        // Prepare and bind the SQL query to update the record
        $stmt = $conn->prepare("UPDATE hsrp SET name = ?, email = ?, phone = ?, address = ? WHERE wheeler_re_no = ?");
        
        // Check if prepare() was successful
        if ($stmt === false) {
            die("Error preparing statement: " . $conn->error);
        }

        $stmt->bind_param("sssss", $name, $email, $phone, $address, $wh_r_no);

        // Execute the query
        if ($stmt->execute()) {
            // After successful update, redirect to the confirmation page or display a success message
            header("Location: entered-form.php"); 
            exit(); // Make sure no further code is executed after redirect
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Please fill out all required fields.";
    }
}

// Close the connection
$conn->close();
?>

<html>
    <head>
        <link rel="stylesheet" href="../public/style/style.css">
    </head>
    <body>
            <header>
                <div class="head-sec">
                    <h1>HSRP Online Booking</h1>
        
            <nav>
                <a href="#home" onclick="window.location.href='../public/index.php'">Home</a>
                <a href="#contact-us" onclick="window.location.href='../public/contact.php'">Contact Us</a>
                <a href="#privacy-policy">Privacy Policy</a>
                <a href="#refund-policy" onclick="window.location.href='../public/refund_policy.php'">Refund Policy</a>
                <a href="#terms-conditions" onclick="window.location.href='../public/terms.php'">Terms & Conditions</a>
                
            </nav>
                </div>
                <marquee behavior="scroll" direction="left" class="float-content">Booking Open for all states <span>Book Your High-Security Number Plates (HSRP) - HSRP Booking Now Open</span>  - It's now easier than ever to re-gister your Wheeler and Book the mandatory High-Security Number Plates</marquee>
        
            </header>
        <div class="container" id="payment-details">
            
            <div id="user-details" class="">
                <h2>User Details</h2>
                <form action="user-form.php" method="POST">
                <input type="hidden" name="wh_r_no" value="<?php echo $_GET['wh_r_no']; ?>"> 

                    <label for="name">Name: <spa class="req_field">*</spa></label>
                    <input type="text" id="name" name="name" value="" placeholder="Your full name" required>
    
                    <label for="email">Email: <spa class="req_field">*</spa></label>
                    <input type="email" id="email" name="email" value="" placeholder="example@domain.com" required>
    
                    <label for="phone">Phone: <spa class="req_field">*</spa></label>
                    <input type="tel" id="phone" name="phone" value="" placeholder="123-456-7890" required>
                    
                    <label for="delivery">Delivery Address: <spa class="req_field">*</spa></label>
                    <input type="text" id="address" name="address" value="" placeholder="Address" required>
    
    
                    <div class="buttons">
                        <button type="button" id="back-booking" onclick="window.location.href='booking-form.php'">Back to Booking</button>
                        <button type="submit" id="to-entered_details" onclick="window.location.href='entered-form.php'">Entered Details</button>
                    </div>
                </form>
            </div>
        </div>
        <footer>
            <p>&copy; 2024 HSRP. All rights reserved.</p>
        </footer>
    
        <script src="../public/script/script.js"></script>
        
    </body>
</html>
